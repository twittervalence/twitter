setwd("D:/LBS Project/KDE_R")
library(rgdal)
library(ks)
Vienna<-readOGR(dsn="Data/Vienna",layer="Vienna")
Vienna$polarity<-as.numeric(as.character(Vienna$polarity))
#divide the data into different months
par(mfrow=c(3,4))

kde_series <- function(data){
  #calculate the bandwidth
  #plug-in method
  Hpi <- Hpi(x = data)
  #LSCV
  Hlscv <- Hlscv(x=data)
  #BCV
  Hbcv <- Hbcv(x = data)
  #SCV
  Hscv <- Hscv(x = data)
  
  #calculate the kde
  kde1<-kde(x = data, H =Hpi)
  kde2<-kde(x = data, H =Hlscv)
  kde3<-kde(x = data, H =Hbcv)
  kde4<-kde(x = data, H =Hscv)
  
  #plot the kde
  plot(kde1,xlab="X",ylab="Y",main="Plug-in",display="filled.contour2")
  plot(kde2,xlab="X",ylab="Y",main="Lscv",display="filled.contour2")
  plot(kde3,xlab="X",ylab="Y",main="BCV",display="filled.contour2")
  plot(kde4,xlab="X",ylab="Y",main="SCV",display="filled.contour2")
  
}
for (i in 10:12){
  data<- coordinates(subset(Vienna, polarity > 0 & month == i))
  kde_series(data)
}

